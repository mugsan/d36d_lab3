package lab3Server;

public enum ServerState {
	Connected,
	Disconnecting
}
