package lab3Client;

public enum ClientState {
	Connecting,
	Connected,
	Disconnecting,
	Disconnected
}
