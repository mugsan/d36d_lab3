package lab3Client;

import java.net.InetAddress;

public class ListItem {
	public InetAddress address = null;
	public int 		      port = 0;
}
