package lab3DataPacket;

public enum MsgType {
	Join,
	Leave,
	Move,
	NewPlayer,
	PlayerLeft,
	PlayerMoved
}
